import time
import random

def print_sleep(message, wait_time):
    print(message)
    time.sleep(wait_time)

def combat(weapon, enemy):
    print_sleep("OH NO!! A {} appears!".format(enemy), 2)
    if weapon != 'dagger':
        print_sleep("You fight the {} with a {}.".format(enemy, weapon), 2)
        print_sleep("You have defeated the enemy and won the game!", 2)
        return 'win'
    else:
        print_sleep("You're trying to fight with a dagger.", 2)
        print_sleep("But the {} isn't budging.".format(enemy), 2)
        print_sleep("You lost the battle.", 2)
        return 'lose'

def play_again():
    while True:
        again = input("Want to play again? (y/n): ")
        if again.lower() == 'y':
            return 'running'
        elif again.lower() == 'n':
            print("Hope you enjoyed the game!!")
            return 'exit'
        else:
            print("Enter 'y' or 'n'.")

def intro():
    print_sleep("You find yourself standing in a beautiful abandoned garden.", 2)
    print_sleep("People say that a {} is somewhere around here, who's been terrifying the nearby village.".format(enemy), 2)
    print_sleep("There's a house in front of you.", 2)
    print_sleep("There's a cave on your right.", 2)
    print_sleep("In your hand you hold your weapon {}.".format(weapon), 2)

def where_to():
    while True:
        choice = input("To knock on the door of the house press 1.\n"
                       "To peer into the cave press 2.\n"
                       "What would you like to do? (Enter 1 or 2): ")
        if choice == '1':
            return house()
        elif choice == '2':
            return cave()
        else:
            print("Invalid input. Just enter 1 or 2.")

def house():
    print_sleep("You walk towards the house and knock on the door.", 2)
    print_sleep("The door opens, it's the {}.".format(enemy), 2)
    return combat(weapon, enemy)

def cave():
    global cave_visited, weapon
    print_sleep("You enter the cave.", 2)
    if not cave_visited:
        print_sleep("It’s dark, but you spot something shiny.", 2)
        print_sleep("You have found a sword!", 2)
        weapon = "sword"
        cave_visited = True
        print_sleep("You return to the field.", 2)
        return where_to()
    else:
        print_sleep("You were already here.", 2)
        print_sleep("You return to the field.", 2)
        return where_to()

# Main game loop
game_state ='running'

while game_state == 'running':
    enemies = ['troll','wicked fairy','pirate','gorgon','dragon']
    enemy = random.choice(enemies)
    weapon = 'dagger'
    cave_visited = False

    intro()
    result = where_to()
    game_state = play_again()
